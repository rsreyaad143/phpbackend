<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Pic Share</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
   
</head>
<body>


    <header>
        <div class="container">
            <div class="header">
                <div class="logo-area">
                    <img src="image/logo.png" alt="logo">
                    <h1><a href="index.php">PIC SHARE</a></h1>
                </div>
                <div class="link-area">
                    <ul>
                        <li><a href="login.php">Log In</a></li>
                        <li><a href="register.php">Register</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <div class="container main-content">
    <h2>WELCOME TO PIC SHARE</h2>
    <h2>Share Your Most Favorite Photo With Your Friend</h2>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati, perspiciatis beatae id eligendi tenetur totam quod impedit temporibus pariatur, hic enim minima, voluptatem ex omnis voluptatibus magnam! Mollitia distinctio pariatur quidem eaque nobis, recusandae, voluptatibus cupiditate a enim eos facilis officiis asperiores porro cum obcaecati autem dolores qui quasi quo inventore itaque optio. Voluptatem sequi et accusantium corrupti nemo at! Qui ab cupiditate dicta iure tenetur iste hic culpa ratione cum. Ipsa praesentium officiis voluptatibus ipsam cum qui a voluptate facilis tempore quisquam aspernatur rem deleniti ut veniam cupiditate esse est eos omnis, fugiat architecto! Labore, aliquid incidunt voluptas delectus nihil eius asperiores in quasi aliquam expedita, necessitatibus quis voluptates corporis consectetur assumenda esse sunt error deserunt possimus cumque sequi numquam beatae. Corrupti impedit placeat saepe! Atque cum eaque animi, distinctio molestias aspernatur. Id odit blanditiis ullam quae atque nesciunt deserunt dolores amet? Sed quod omnis reiciendis sapiente obcaecati quaerat repellendus rem corrupti facere excepturi! Aut ullam autem ipsam quidem quia quam soluta? Neque consequatur beatae excepturi rem facere expedita minus possimus voluptas voluptatibus officiis. Natus adipisci fugit eum necessitatibus obcaecati officiis dolor temporibus porro at ut, reiciendis sed repudiandae suscipit animi numquam nobis quibusdam et saepe quaerat eligendi maiores reprehenderit commodi accusantium delectus. Omnis eius earum voluptatem sequi illum, ullam saepe quibusdam enim exercitationem ratione odit, incidunt eum qui illo numquam debitis corporis tenetur nemo voluptatum! Quasi similique perspiciatis blanditiis dignissimos, corrupti porro odit delectus quibusdam obcaecati minima ipsa excepturi facilis. Nisi, a. Aut alias sapiente, facere quisquam maiores nihil nobis modi vero libero tenetur nisi fuga labore distinctio commodi rem, voluptatum aspernatur recusandae doloribus reiciendis voluptas esse architecto neque dolorum officiis? Repellendus, eaque ullam ad accusantium magni doloremque esse numquam quod repudiandae libero dignissimos molestiae cum? Quas expedita vitae quis fugit accusantium tenetur dolore, sint labore iusto ducimus?</p>
    </div>




    
    
    <script src="jquery.js"></script>
    <script src='main.js'></script>
</body>
</html>