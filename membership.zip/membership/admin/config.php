<?php

    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $database = 'membership';

    $connection = mysqli_connect($host, $user, $pass, $database);


?>